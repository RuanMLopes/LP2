﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLacos
{
    public partial class FrmEx4 : Form
    {
        public FrmEx4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double salarioBruto, gratificacao, A;
            int B = 0, C = 0, D = 0, producao;

            gratificacao = double.Parse(txtGratificacao.Text);
            A = double.Parse(txtSalario.Text);
            producao = int.Parse(txtProducao.Text);

            if (producao >= 100)
                B = 1;
            if (producao >= 120)
                C = 1;
            if (producao >= 150)
                D = 1;

            salarioBruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + gratificacao;

            MessageBox.Show("Nome: "+txtNome.Text.ToString()+"\nCargo: "+txtCargo.Text.ToString()+"\nMatrícula: "+txtMatricula.Text.ToString()+"\n\nSalário Bruto: "+salarioBruto.ToString());
        }
    }
}
