﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLacos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Exercício1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmEx1>().Count() > 0)
            {
                MessageBox.Show("Exercício já existe");
                Application.OpenForms["FrmEx1"].BringToFront();
            }
            else
            {
                FrmEx1 obj1 = new FrmEx1();
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void Exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmEx2>().Count() > 0)
            { 
                MessageBox.Show("Exercício já existe");
                Application.OpenForms["FrmEx2"].BringToFront();
            }
            else
            {
                FrmEx2 obj2 = new FrmEx2();
                obj2.MdiParent = this;
                obj2.WindowState = FormWindowState.Maximized;
                obj2.Show();
            }
        }

        private void Exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmEx3>().Count() > 0)
            { 
                MessageBox.Show("Exercício já existe");
                Application.OpenForms["FrmEx3"].BringToFront();
            }
            else
            {
                FrmEx3 obj3 = new FrmEx3();
                obj3.MdiParent = this;
                obj3.WindowState = FormWindowState.Maximized;
                obj3.Show();
            }
        }

        private void Exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmEx4>().Count() > 0)
            { 
                MessageBox.Show("Exercício já existe");
                Application.OpenForms["FrmEx4"].BringToFront();
            }
            else
            {
                FrmEx4 obj4 = new FrmEx4();
                obj4.MdiParent = this;
                obj4.WindowState = FormWindowState.Maximized;
                obj4.Show();
            }
        }

        private void SairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
