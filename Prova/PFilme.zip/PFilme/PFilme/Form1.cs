﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnExecutar_Click(object sender, EventArgs e)
        {
            string auxiliar1, auxiliar2;
            float[,] notas = new float[90, 2];
            float media1 = 0, media2 = 0;

            for (var i = 0; i < 90; i++)
            {
                auxiliar1 = Interaction.InputBox("Insira a nota", "Nota filme 1");
                auxiliar2 = Interaction.InputBox("Insira a nota", "Nota filme 2");

                if (!float.TryParse(auxiliar1, out notas[i, 0]))
                {
                    MessageBox.Show("Favor entrar com um valor válido");
                }
                else if (notas[i,0] >= 0 || notas[i, 0] <= 10)
                {
                    if (!float.TryParse(auxiliar2, out notas[i, 1]))
                    {
                        MessageBox.Show("Favor entrar com um valor válido");
                    }
                    else
                    {
                        media1 += notas[i, 0];
                        media2 += notas[i, 1];
                    }
                }
            }

            media1 = media1 / 90;
            media2 = media2 / 90;

            for (var i = 0; i < 90; i++)
            {
                lstNotas.Items.Add("Pessoa "+(i+1)+" Nota Filme 1: "+notas[i,0].ToString("N2")+" Nota Filme 2: " + notas[i, 1].ToString("N2"));
            }

            lstNotas.Items.Add("\n--------------------------------------------------------------------------------------\n");
            lstNotas.Items.Add("Média Filme 1: " + media1.ToString("N2"));
            lstNotas.Items.Add("Média Filme 2: " + media2.ToString("N2"));
        }
    }
}
