﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMenu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CopiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Opção CTRL+C");
        }

        private void ColarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Opção CTRL+V");
        }

        private void SairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void ContextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void Exercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio2 objForm2 = new frmExercicio2();
            objForm2.MdiParent = this;
            objForm2.WindowState = FormWindowState.Maximized;
            objForm2.Show();
        }

        private void exercicio5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio5 objForm5 = new frmExercicio5();
            objForm5.MdiParent = this;
            objForm5.WindowState = FormWindowState.Maximized;
            objForm5.Show();
        }

        private void exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio3 objForm3 = new frmExercicio3();
            objForm3.MdiParent = this;
            objForm3.WindowState = FormWindowState.Maximized;
            objForm3.Show();
        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio4 objForm4 = new frmExercicio4();
            objForm4.MdiParent = this;
            objForm4.WindowState = FormWindowState.Maximized;
            objForm4.Show();
        }
    }
}
